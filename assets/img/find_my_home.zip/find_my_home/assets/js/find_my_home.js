
// $(window).resize(function () {
//     var $sliderWidth = $(window).width();
//     if ($sliderWidth > 768) 
//     {
// 	    function nextSlider() 
// 	    {
// 			indexValue++;
// 			sliderValue = sliderValue+18;
// 			$(".slider").animate({"margin-left":"-"+sliderValue+"%"},1000);
// 			if (indexValue==3)
// 			{
// 				sliderValue = 0;
// 				indexValue =0;
// 			}
// 		}
//     }
// });

// click slider
var sliderValue = 0;
var indexValue = 0;
$(".next").click(function () {nextSlider();});

// click slider
var previousSliderValue = 0;
var previousIndexValue = 0;
$(".previous").click(function () {previousSlider();});

// slider function
function previousSlider() {
	previousIndexValue++;
	previousSliderValue = previousSliderValue-68;
	$(".cumsSlider").animate({"margin-left":+previousSliderValue+"%"},1000);
	if (previousIndexValue==3)
	{
		previousSliderValue = 0;
		previousIndexValue =0;
	}
}

// auto slider
setInterval(function(){nextSlider();},2000)

// slider function
function nextSlider() {
	indexValue++;
	sliderValue = sliderValue+68;
	$(".cumsSlider").animate({"margin-left":"-"+sliderValue+"%"},1000);
	if (indexValue==3)
	{
		sliderValue = 0;
		indexValue =0;
	}
}

// Menu
$(".menu_icon").click(function(){
	$(".menu_list").animate({"width": '30%'},300);
});

$(".close_menu").click(function() {
	$(".menu_list").animate({"width": "0%"},300);
})

// mobile house filter
$(".rent_buy li").click(function () {
    var obj = $(this);
    obj.addClass('active').siblings().removeClass("active");
});

$(".paginations ul li").click(function () {
    var activePageObj = $(this);
    activePageObj.addClass('active_page').siblings().removeClass("active_page");
});

$(".rent_buy .buy").click(function () {
	$(".more_opsn").css({"display":"flex"})    
});

// rent_list li bg change
$(".rent_list li").click(function () {
    var newObj = $(this);
    newObj.addClass('active_bg').siblings().removeClass("active_bg");
});

// buy
	var isClicked = false;
$(".more_opsn").click(function(){
	if (isClicked==false)
	{
		$(".hero_section").css({"height":"900px"});
		$(".apart_build,.invest").css({"display":"flex"});
		$(".rent_list").css({"flex-wrap":"wrap"});
		isClicked = true;
	}
	else
	{
		$(".hero_section").css({"height":"765px"});
		$(".apart_build,.invest").css({"display":"none"});
		isClicked = false;
		console.log("no");
	}
});

// email validation
// $(".email").on("input",function()
// {
// 	var gamil_str = $(this).val();
// 	let pattern = /^[^ ]+@[^]+\.[a-z]{2,3}$/   //reg-ular ex-pression
	
// 	if (gamil_str.match(pattern))  
// 	{
// 	  $(this)
// 	}
// });

// 										Adjust Result JS

$(".buy_container ul li,.search_container ul li,.room_container ul li").click(function(){
	var newObjBuy = $(this);
    newObjBuy.addClass('active_bg_buy').siblings().removeClass("active_bg_buy");
});

// fedral_state_container
$(".show").click(function() {
	$(".fedral_state_container,.district_container").css({"display":"flex"});
	$(".postcode_container").css({"display":"none"});
});

$(".hide").click(function() {
	$(".fedral_state_container,.district_container").css({"display":"none"});
	$(".postcode_container").css({"display":"flex"});
});

// show_all_btn
$(".show_all_btn").click(function(){
	$(".show_all_list").css({"display":"flex"});
});


// 										Details Page js

// Accordion
$(".accordin_card .title").click(function(){
	$(".accordin_card>ul").toggleClass("accordin_card_body");
	$(".accordin_card>.title>.fa-chevron-up").toggleClass("rotate");
});

$(".accordin_card_two .titl").click(function(){
	$(".accordin_card_two>ul").toggleClass("accordin_card_bodi");
	$(".accordin_card_two>.titl>.fa-chevron-up").toggleClass("rotat");
});

$(".accordin_card_sub .sub_title").click(function(){
	console.log("ok");
	$(".accordin_card_sub ul").toggleClass("sub_accordin_card_body");
	$(".accordin_card_sub>.sub_title>.fa-chevron-down").toggleClass("sub_rotate");
});