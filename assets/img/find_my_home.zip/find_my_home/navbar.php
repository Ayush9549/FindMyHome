            <div class="rental_types d-flex align-items-end justify-content-end">
              <ul class="list-unstyled text-decoration-none d-flex">
                <li> <a class="border-end border-2" title="Eigentumswohnungen zum Kaufen in Wien" href="condominiums_list.php">Condominiums Vienna </a></li>
                <li> <a class="border-end border-2" title="Wohnungen in Wien" href="#">Apartments Vienna</a></li>
                <li> <a title="Mietwohnungen in Wien mieten" href="#">Rental Apartments Vienna</a></li>
              </ul>
            </div>
            <!-- Nav Start -->
            <nav class=" mt-3 mb-0">
              <div class="d-none text-white align-items-center gap-2 menu_icon"><i class="fa-sharp fa-solid fa-bars"></i> MENU</div>

              <ul class="list-unstyled menu_items d-flex p-0 m-0 gap-4">
                <li></li>
                <li><a href="index.php"><span class=" d-none"><i class="fa-solid fa-house-chimney"></i></span><span>Home</span></a></li>
                <li><a href="#">Seek</a></li>
                <li><a href="#"><span class="d-none">Offer</span><span>Offer Real Estate</span></a></li>
                <li><a href="#">Quality Programm</a></li>
                <li><a href="#">Worth Reading</a></li>
                <li><a href="register.php">Search Agent</a></li>
                <li><a href="#">Helper</a></li>
              </ul>
            </nav>
            <div class="menu_list position-absolute">
              <span class="w-100 d-flex align-items-center gap-2 justify-content-end p-3 close_menu">Close <i class="fa-solid fa-x fs-3"></i></span>
              <h3 class="border-2 border-bottom text-center mx-4 pb-4">YOU'LL BE AT HOME SOON!</h3>
              <div class="px-5">
                <ul class="list-unstyled text-white text-nowrap">
                  <li><a href="index.php">Home</a></li>
                  <li><a href="#">Search Real Estate</a></li>
                  <li><a href="#">Offer Real Estate</a></li>
                  <li><a href="#">Quality Program</a></li>
                  <li><a href="#">Worth Reading</a></li>
                  <li><a href="#">Helper</a></li>
                  <li><a href="register.php">Search Agent</a></li>
                  <li><a href="#"><i class="fa-sharp fa-regular fa-gem"></i> Premium Living</a></li>
                </ul>
              </div>
            </div>