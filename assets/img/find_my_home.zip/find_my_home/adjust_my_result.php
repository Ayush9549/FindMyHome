<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="./assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="./assets/css/adjust_my_result.css">
    <link rel="icon" type="text/css" href="./assets/img/favicon-128.png">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
  </head>
  <body>
    <section class="adjust_my_result">
      <div class="wrapper">
        <div class="row gap-4 p-0 m-0">
          <!-- Header Start -->
          <header class="">
            <div class="row p-0 m-0">
              <div class="logo d-flex p-0 m-0 col-4">
                <a href="index.php">
                  <img title="To Home Page" src="./assets/img/FindMyHome-at-Logo.svg" alt="">
                </a>
              </div>
              <div class="col-6 header_ad p-0 m-0">
                <a href="#">
                  <img src="./assets/img/78438a31fde50ab1dc2c9467a0d5aa4e.jpg" alt="">
                </a>
              </div>
            </div>
          </header>
          <!-- Header end -->
          <div class="col-12 p-0 m-0">
            <?php include 'navbar.php'; ?>
            <!-- Nav end -->
            <div class="my-3">Apply changes and view my properties</div>
            <div class="fs-5 mb-4">REFINE YOUR SEARCH</div>
            <div class="row buy_container border-bottom p-0 m-0 pb-4">
              <div class="col-3 p-0 m-0">
                <div class="title"><strong>I want to buy</strong> a property</div>
              </div>
              <div class="col-9 p-0 m-0">
                <ul class="list-unstyled d-flex flex-wrap gap-4">
                  <li class="active_bg_buy border">Apartment</li>
                  <li class="border">House</li>
                  <li class="border">Property</li>
                  <li class="border">Apartment Building</li>
                  <li class="border">Special Object</li>
                  <li class="border">investment</li>
                </ul>
              </div>
            </div>
            <div class="row buy_container border-bottom p-0 m-0 mt-5 pb-4">
              <div class="col-3 p-0 m-0">
                <div class="title"><strong>I want to rent</strong> a property</div>
              </div>
              <div class="col-9 p-0 m-0">
                <ul class="list-unstyled d-flex flex-wrap gap-4">
                  <li class="border">Apartment</li>
                  <li class="border">House</li>
                  <li class="border">Property</li>
                  <li class="border">Special Object</li>
                </ul>
              </div>
            </div>
            <div class="row room_container p-0 m-0 mt-5">
              <div class="col-3 p-0 m-0">
                <div class="title"><strong>Room</strong></div>
              </div>
              <div class="col-9 p-0 m-0">
                <ul class="list-unstyled d-flex flex-wrap gap-4">
                  <li class="border active_bg_buy">Any</li>
                  <li class="border">Form 1</li>
                  <li class="border">Startig at 2</li>
                  <li class="border">From 3</li>
                  <li class="border">From 4</li>
                </ul>
              </div>
            </div>
            <div class="row surface_container p-0 m-0 mt-5">
              <div class="col-3 p-0 m-0">
                <div class="title"><strong>Surface</strong></div>
              </div>
              <div class="col-9 p-0 m-0 d-flex gap-4">
                <input type="number" name="" placeholder="From">
                <input type="number" name="" placeholder="Until">
              </div>
            </div>
            <div class="row surface_container border-bottom p-0 m-0 mt-4 pb-4">
              <div class="col-3 p-0 m-0">
                <div class="title"><strong>Price</strong></div>
              </div>
              <div class="col-9 p-0 m-0 d-flex gap-4">
                <input type="number" name="" placeholder="From">
                <input type="number" name="" placeholder="Until">
              </div>
            </div>
            <div class="row search_container p-0 m-0 mt-4">
              <div class="col-3 p-0 m-0">
                <div class="title"><strong>Search For</strong></div>
              </div>
              <div class="col-9 p-0 m-0 d-flex align-items-center gap-4">
                <ul class="list-unstyled d-flex align-items-center flex-wrap gap-4 w-100">
                  <li class="active_bg_buy border hide">Postcode</li>
                  <span>or</span>
                  <li class="border show">Region</li>
                </ul>
              </div>
            </div>
            <div class="row postcode_container p-0 m-0 mt-3 pb-3">
              <div class="col-3 p-0 m-0">
                <div class="title"><strong>Postcode</strong></div>
              </div>
              <div class="col-9 p-0 m-0 d-flex gap-4">
                <input type="number" name="" placeholder="e.g. 1190">
              </div>
            </div>
            <div class="row fedral_state_container p-0 m-0 mt-1">
              <div class="col-3 p-0 m-0">
                <div class="title"><strong>Federal State</strong></div>
              </div>
              <div class="col-9 p-0 m-0 d-flex align-items-center flex-column">
                <ul class="list-unstyled d-flex align-items-center flex-wrap gap-4 w-100">
                  <li class="active_bg_buy border">Vienna</li>
                  <span class="show_all_btn">Show All</span>
                </ul>
                <ul class="list-unstyled show_all_list flex-wrap gap-4">
                  <li class="border">Burgenland</li>
                  <li class="border">Carinthia</li>
                  <li class="border">Lower Austria</li>
                  <li class="border">Upper Austria</li>
                  <li class="border">Salzburg</li>
                  <li class="border">Styria</li>
                  <li class="border">Tyrol</li>
                  <li class="border">Vorarlberg</li>
                  <li class="border">Vienna Area</li>
                </ul>
              </div>
            </div>
            <div class="row district_container p-0 m-0 mt-1">
              <div class="col-3 p-0 m-0">
                <div class="title"><strong>District</strong></div>
              </div>
              <div class="col-9 p-0 m-0 d-flex align-items-center">
                <ul class="list-unstyled d-flex flex-wrap gap-4">
                  <li class="border">Vienna(Total)</li>
                  <li class="border">Vienna 1st,inner city</li>
                  <li class="border">2nd district of Vienna, Leopoldstadt</li>
                  <li class="border">Vienna 3rd, country road</li>
                  <li class="border">Vienna 4th, Wieden</li>
                  <li class="border">Vienna 5th, Margareten</li>
                  <li class="border">Vienna 6th, Mariahilf</li>
                  <li class="border">7th district of Vienna, new building</li>
                  <li class="border">8th district of Vienna, Josefstadt</li>
                  <li class="border">9th district of Vienna, Alsergrund</li>
                  <li class="border">Vienna 10th, favorites</li>
                  <li class="border">Vienna 11th, Simmering</li>
                  <li class="border">12th district of Vienna, Meidling</li>
                  <li class="border">13th district of Vienna, Hietzing</li>
                  <li class="border">Vienna 14th, Penzing</li>
                  <li class="border">Vienna 15th district, Rudolfsh.-Funfhaus</li>
                  <li class="border">16th district of Vienna, Ottakring</li>
                  <li class="border">Vienna 17th, Hernals</li>
                  <li class="border">18th district of Vienna, Wahring</li>
                  <li class="border">19th district of Vienna, Dobling</li>
                  <li class="border">Vienna 20th, Brigittenau</li>
                  <li class="border">Vienna 21st, Floridsdorf</li>
                  <li class="border">Vienna 22nd, Donaustadt</li>
                  <li class="border">Vienna 23rd, Liesing</li>
                </ul>
              </div>
            </div>
            <div class="row p-0 m-0">
              <div class="col-12 p-0 m-0 d-flex justify-content-center">
                <button class="border-0 view_my_properties">VIEW MY PROPERTIES</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <script type="text/javascript" src="./assets/js/find_my_home.js"></script>
  </body>
</html>