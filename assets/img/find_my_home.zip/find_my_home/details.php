<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="./assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="./assets/css/details.css">
    <link rel="icon" type="text/css" href="./assets/img/favicon-128.png">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
  </head>
  <body>
    <section class="details">
      <div class="wrapper">
        <div class="row p-0 m-0">
          <!-- Header Start -->
          <header class="">
            <div class="row p-0 m-0">
              <div class="logo d-flex p-0 m-0 col-4">
                <a href="index.php">
                  <img title="To Home Page" src="./assets/img/FindMyHome-at-Logo.svg" alt="">
                </a>
              </div>
              <div class="col-6 header_ad p-0 m-0">
                <a class="w-100 d-flex" href="#">
                  <img src="./assets/img/78438a31fde50ab1dc2c9467a0d5aa4e.jpg" alt="">
                </a>
              </div>
            </div>
          </header>
          <!-- Header end -->
          <div class="col-12 p-0 m-0">
            <?php include 'navbar.php'; ?>
            <!-- Nav end -->
            <div class="row p-0 m-0 mt-3">
              <div class="col-6 ps-0 m-0 back_result_page"><a class="d-flex align-items-center text-white w-100" href="condominiums_list.php"><i class="fa-solid fa-arrow-left me-2"></i>BACK TO MY RESULT LIST</a></div>
              <div class="col-6 py-0 pe-0 m-0 ps-4 d-flex justify-content-between align-items-center">
                <a href="#">
                  <i class="fa-solid fa-chevron-left"></i>
                </a>
                <span>Property <strong>2952</strong> of <strong>4164</strong></span>
                <a href="#">
                  <i class="fa-solid fa-chevron-right"></i>
                </a>
              </div>
              <div class="col-12 p-0 m-0 mt-2"><h5>1220, Lobaugasse, green area, only 5 minutes by bike from the U2, 3-room apartment - property no. 4907896</h5></div>
            </div>
            <div class="sticky w-100 mt-3">
              <div class="row sticky_img w-100 justify-contnet-between p-0 m-0 pb-3 border-bottom border-1">
                <div class=" col-8 p-0 m-0">
                  <!-- Swiper -->
                  <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                  <div class="swiper mySwiper2">
                    <div class="swiper-wrapper">
                      <div class="swiper-slide">
                        <img src="./assets/img/P0270331768.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="swiper-slide">
                        <img src="./assets/img/P0270331767.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="swiper-slide">
                        <img src="./assets/img/P0270331994.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="swiper-slide">
                        <img src="./assets/img/P0270331993.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="swiper-slide">
                        <img src="./assets/img/P0270332012.jpg" class="d-block w-100" alt="...">
                      </div>
                    </div>
                  </div>
                  <div thumbsSlider="" class="swiper mySwiper mt-2">
                    <div class="swiper-wrapper gap-3">
                      <div class="swiper-slide">
                        <img src="./assets/img/P0270331768.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="swiper-slide gap-3">
                        <img src="./assets/img/P0270331767.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="swiper-slide gap-3">
                        <img src="./assets/img/P0270331994.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="swiper-slide gap-3">
                        <img src="./assets/img/P0270331993.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="swiper-slide gap-3">
                        <img src="./assets/img/P0270332012.jpg" class="d-block w-100" alt="...">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-4 p-0 m-0  pt-5 d-flex flex-wrap gap-4">
                  <ul class="list-unstyled d-flex flex-column align-items-center">
                    <li>1220</li>
                    <hr>
                    <li>Location</li>
                  </ul>
                  <ul class="list-unstyled d-flex flex-column align-items-center">
                    <li><a href="#">&euro; 849,900.00</a></li>
                    <hr>
                    <li>Purchase Price</li>
                  </ul>
                  <ul class="list-unstyled d-flex flex-column align-items-center">
                    <li>94.91 m<sup>2</sup></li>
                    <hr>
                    <li>Surface</li>
                  </ul>
                  <ul class="list-unstyled d-flex flex-column align-items-center">
                    <li>3</li>
                    <hr>
                    <li>Room</li>
                  </ul>
                  <div class="btns mt-3">
                    <ul class="list-unstyled d-flex flex-wrap gap-4">
                      <li class=" text-white"><a href="#"><i class="fa-solid fa-phone me-1"></i>PHONE CALL</a></li>
                      <li class=" text-white"><a href="#"><i class="fa-solid fa-envelope me-1"></i>E-MAIL</a></li>
                      <li class="bg-white"><a href="#"><i class="fa-sharp fa-solid fa-share-nodes me-1"></i>PHONE CALL</a></li>
                      <li class="bg-white"><i class="fa-solid fa-magnifying-glass me-1"></i>SEARCH AGENT</li>
                    </ul>
                  </div>
                </div>
              </div>
              
              <div class="row p-0 m-0 mt-4">
                <div class="col-12 p-0 m-0 ps-3">
                  <div class="accordin">
                    <div class="accordin_card pb-4 mt-3">
                      <div class="title"><i class="fa-solid fa-list me-5 rounded-circle"></i>KEY DATA <i class="fa-solid fa-chevron-up bg-white text-dark"></i></div>
                      <ul class="list-unstyled accordin_card_body d-none mt-4">
                        <li class="d-flex justify-content-between align-items-center p-1"><span>FindMyHome.at // External property ID</span><span>4907896 // TNR002703</span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>property type</span><span>Apartment - property</span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>Address</span><span>1220 Vienna</span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>Construction year</span><span>2023</span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>old or new building</span><span>New Building</span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>Heating</span><span>Central Heating</span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>lift</span><span>Yes</span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>Surface</span><span>94.91 m<sup>2</sup></span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>Terraces</span><span>2 (52.71 m<sup>2</sup>)</span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>Room</span><span>3</span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>Bath</span><span>1</span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>WC</span><span>2</span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>Purchase price:</span><span>&euro;849,900.00</span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>Installment Payment:</span><span><a class="text-decoration-underline" href="#">View financing options for this property</a></span></li>
                      </ul>
                      <div class="accordin_card_sub mt-3 py-2 px-3">
                        <div class="sub_title">
                          <i class="fa-brands fa-canadian-maple-leaf me-3"></i>
                          Show Energy Performance Certificate
                          <i class="fa-solid fa-chevron-down text-dark"></i>
                        </div>
                        <ul class="list-unstyled  d-none mt-1 mb-3">
                          <li>Energy pass type: REQUIREMENT</li>
                          <li>Energy pass validity: 22.11.2030</li>
                          <li>Heating requirement in kWh/m2/year: 29</li>
                          <li>Total energy efficiency factor: 0.7</li>
                        </ul>
                      </div>
                    </div>
                    <ul class="list-unstyled ads d-flex gap-4 flex-wrap mt-3 pb-3">
                      <li><a class="d-flex align-items-center text-inherit w-100" href="#"><i class="fa-solid fa-chart-pie me-1"></i>Compare installment loans</a></li>
                      <li><a class="d-flex align-items-center text-inherit w-100" href="#"><i class="euro me-1">&euro;</i>Compare Electricity & Gas costs</a></li>
                      <li><a class="d-flex align-items-center text-inherit w-100" href="#"><i class="fa-solid fa-couch me-1"></i>Compare Home Insurance</a></li>
                      <li><a class="d-flex align-items-center text-inherit w-100" href="#"><i class="fa-regular fa-lightbulb me-1"></i>Compare fixed costs</a></li>
                    </ul>
                    <div class="accordin_card_two mt-3">
                      <div class="titl"><i class="fa-solid fa-bars me-5 rounded-circle"></i>DESCRIPTION <i class="fa-solid fa-chevron-up bg-white text-dark"></i></div>
                      <ul class="list-unstyled accordin_card_bodi d-none mt-4">
                        <li class="d-flex justify-content-between align-items-center p-1"><span>FindMyHome.at // External property ID</span><span>4907896 // TNR002703</span></li>
                        <li class="d-flex justify-content-between align-items-center p-1"><span>property type</span><span>Apartment - property</span></li>
                        <li><span>Address</span></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="request_btn d-flex justify-content-center align-items-center py-2 fw-bold">REQUEST A SHOWING</div>
          </div>
          <div class="col-3 p-0 m-0">
            <img src="./assets/img/download8.png" alt="">
          </div>
        </div>
      </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <script type="text/javascript" src="./assets/js/find_my_home.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script>
    var swiper = new Swiper(".mySwiper", {
    spaceBetween: 0,
    slidesPerView: 4,
    freeMode: true,
    watchSlidesProgress: true,
    });
    var swiper2 = new Swiper(".mySwiper2", {
    spaceBetween: 0,
    navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
    },
    thumbs: {
    swiper: swiper,
    },
    });
    </script>
  </body>
</html>